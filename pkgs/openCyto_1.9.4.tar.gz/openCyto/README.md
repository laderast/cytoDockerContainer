openCyto
========

An R package that providing an automated data analysis pipeline for flow cytometry.

See the [github-pages](http://www.opencyto.org) for the package.
